
s = tf('s');
sys = 1/(s*(s+1));
sys  = s*sys;
figure(1)
rlocus(sys)
axis([-6 3 -5 5])
zeta = 0.6;
wn = 3;
sgrid(zeta,wn)
[ka,poles] = rlocfind(sys)

k1 = 1;
nsys = ka/(s^2 + (1+ka*k1)*s);
nsys = nsys * 1/s;
figure(1)
rlocus(nsys)
axis([-14 3 -10 10])
zeta = 0.6;
wn = 3;
sgrid(zeta,wn)
[k2,poles] = rlocfind(nsys)















F = ka / (s^3 + s^2 +ka*k2*s+ ka*k1 )
rlocus(F)
step(F)
stepinfo(F)









